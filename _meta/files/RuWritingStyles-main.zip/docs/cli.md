# CLI

RuWritingStyles CLI starts with a deliberately small command set. It prepares reproducible run artifacts, creates prompts for style agents, can execute them through a provider, and keeps Markdown plus static HTML reports for each run.

## Install for local development

From the repository root:

```bash
python -m pip install -e .
```

After that the `rws` command is available:

```bash
rws show-config
```

Without installation, use `PYTHONPATH=src`:

```bash
PYTHONPATH=src python -m ruwritingstyles.cli show-config
```

In PowerShell:

```powershell
$env:PYTHONPATH='src'
python -m ruwritingstyles.cli show-config
```

## Show configuration

```bash
rws show-config
```

This loads:

- `styles/manifest.yml`;
- MVP style passports from `styles/passports/`;
- `model_policy.yml`.

It prints the MVP styles and the default development model policy.

## Show Model Routes

```bash
rws model-routes
rws model-routes --provider openai --task style_review
```

This prints the task-to-model routes from `model_policy.yml`, including provider-specific reasoning or thinking settings.

## Check Provider Readiness

```bash
rws provider-status
rws provider-status --provider openai
rws provider-status --provider openai --strict
rws provider-status --provider openai --json
rws provider-status --provider openai --json > runs/provider-status-openai.json
rws validate-provider-status runs/provider-status-openai.json
```

This prints whether each provider is ready for real API execution based on environment variables, without exposing API keys. `mock` is always ready. Real providers use `OPENAI_API_KEY`, `GEMINI_API_KEY` or `GOOGLE_API_KEY`, `ANTHROPIC_API_KEY`, `OPENROUTER_API_KEY`, `RWS_LOCAL_LLM_URL`, or `RWS_OLLAMA_URL` depending on the selected provider.

Use `--strict` in scripts when missing provider configuration should return exit code `1`; use `--json` when automation needs structured, secret-free readiness data. Saved JSON can be checked against `schemas/provider-status.schema.json` with `validate-provider-status`.

For local setup, copy `.env.example` to `.env`, fill only the providers you want to run, and keep `.env` uncommitted.

## List styles

```bash
rws list-styles
```

To show only the current MVP council set:

```bash
rws list-styles --mvp
```

MVP styles are marked with `*`. The current default set contains 6 style passports from `mvp_style_ids` in `styles/manifest.yml`.

## List Eval Cases

```bash
rws eval-list
```

This reads `evals/manifest.json` and prints the current comparison cases, their input documents, default styles, expected risks, scoring thresholds, and tags.
The current suite contains 33 cases covering unsupported etymology, over-strong source claims, scholarly register/overconfidence, cluster behavior, adversarial caution, syntax and source discipline.

## Run An Eval Case

```bash
rws eval-run --case pseudo-etymology --provider mock
```

This executes the case through the current pipeline and writes `eval-result.json` into the run directory. Use real providers the same way once API keys are configured:

```bash
rws eval-run --case pseudo-etymology --provider openai --model gpt-5
```

`eval-result.json` includes finding types, matched expected risks, verification status, diff magnitude metrics, and a minimal pass/fail scoring block from `evals/manifest.json`.

## Run The Eval Suite

```bash
rws eval-suite --provider mock
```

This runs every case from `evals/manifest.json` and writes both `runs/<suite-id>/eval-suite-result.json` and `runs/<suite-id>/eval-suite-report.md` with `case_count`, `passed_count`, `failed_count`, `pass_rate`, and per-case result paths. Use `--suite-id` for deterministic local smoke tests:

```bash
rws eval-suite --provider mock --suite-id cli-smoke-suite
rws eval-suite --provider mock --suite-id cli-smoke-suite --strict
rws eval-suite --provider openai --suite-id openai-candidate --compare-to runs/cli-smoke-suite
```

Use `--compare-to` to immediately write `comparison.md` and `comparison.json` in the new suite directory. Use `--strict` when any failed eval case or comparison regression should return exit code `1`.

To validate the suite summary and every referenced case run:

```bash
rws validate-eval-suite runs/cli-smoke-suite
```

## Compare Eval Suites

```bash
rws eval-compare runs/openai-suite runs/gemini-suite
```

The command accepts suite directories or direct `eval-suite-result.json` paths, then prints pass-rate deltas, newly passed cases, regressions, and per-case finding/diff metric changes. Use `--output` to save the comparison as Markdown and `--json-output` for automation:

```bash
rws eval-compare runs/openai-suite runs/gemini-suite --output runs/eval-compare-openai-gemini.md --json-output runs/eval-compare-openai-gemini.json
```

Use `--strict` in CI when a lower candidate pass rate or any per-case regression should return exit code `1`.

Validate a saved comparison JSON with:

```bash
rws validate-eval-comparison runs/eval-compare-openai-gemini.json
```

For short CI logs or quick inspection, use:

```bash
rws eval-status runs/openai-suite
rws eval-status runs/eval-compare-openai-gemini.json
```

## Promote Eval Suite as Baseline

```bash
rws eval-promote runs/cli-smoke-suite --tag gold
```

This promotes the selected suite result to `evals/baselines/gold.json`. This baseline is used for future regression testing in CI.

## Run Regression Tests

```bash
rws eval-regression --provider mock
```

This command runs the full evaluation suite and automatically compares it against the `gold.json` baseline. If any per-case regressions are detected or the pass rate drops, the command returns exit code `1`. This is the primary gate for CI/CD stability.

The repository also includes a manual GitHub Actions workflow, `Eval Smoke`, which runs the mock eval suite, validates it, prints `eval-status`, exports the suite bundle, and uploads the ZIP artifact.

## Export An Eval Suite

```bash
rws export-eval-suite runs/openai-suite
```

The bundle includes `eval-suite-result.json`, `eval-suite-report.md`, any additional top-level suite Markdown/JSON files such as comparison reports, and stable artifacts from each referenced case run under `cases/<run-id>/`.

## Prepare a document

```bash
rws prepare README.md
```

For deterministic smoke tests:

```bash
rws prepare README.md --run-id cli-smoke-readme
```

The command currently supports `.md` and `.txt` inputs. It creates:

```text
runs/<run-id>/
  original.md
  normalized.md
  segments.json
  report.md
  summary.html
```

`runs/` is ignored by Git because run artifacts are local outputs.

## Run the full offline pipeline

```bash
rws run README.md
```

For deterministic smoke tests:

```bash
rws run README.md --run-id cli-smoke-readme
```

By default, `rws run` uses the MVP style set from `styles/manifest.yml`. You can override it:

```bash
rws run README.md --style zalizniak-zametki
rws run README.md --styles zalizniak-ocherk,zalizniak-zametki
```

The command creates the same `runs/<run-id>/` directory as `prepare`, then adds review, council, revision, and verification artifacts.

To execute all generated prompts with the deterministic mock provider:

```bash
rws run README.md --run-id cli-smoke-readme --execute --provider mock
```

To execute with OpenAI, set `OPENAI_API_KEY` and choose `openai`:

```bash
rws run README.md --execute --provider openai --model gpt-5
```

OpenAI execution uses the Responses API with Structured Outputs. It is opt-in so local tests never require secrets or network access.

Other opt-in provider adapters use the same run artifacts:

```bash
rws run README.md --execute --provider google --model gemini-2.0-pro
rws run README.md --execute --provider anthropic --model claude-4-sonnet
```

Provider environment variables:

- `openai`: `OPENAI_API_KEY`, optional `RWS_OPENAI_MODEL`, optional `RWS_OPENAI_REASONING`.
- `google`: `GEMINI_API_KEY` or `GOOGLE_API_KEY`, optional `RWS_GOOGLE_MODEL`.
- `anthropic`: `ANTHROPIC_API_KEY`, optional `RWS_ANTHROPIC_MODEL`, optional `RWS_ANTHROPIC_MAX_TOKENS`.
- `openrouter`: `OPENROUTER_API_KEY`, optional `RWS_OPENROUTER_MODEL`.
- `local`: optional `RWS_LOCAL_LLM_URL`, optional `RWS_LOCAL_LLM_MODEL`.
- `ollama`: optional `RWS_OLLAMA_URL`, optional `RWS_OLLAMA_MODEL`.

Use `.env.example` as the local template. The repository ignores `.env` and `.env.*` files so real keys stay out of Git.

Transient provider failures are retried with exponential backoff. Configure this with `RWS_PROVIDER_MAX_ATTEMPTS` and `RWS_PROVIDER_RETRY_SECONDS`. When a provider returns rate-limit headers, the retry layer prefers `Retry-After`, then known OpenAI `x-ratelimit-reset-*` and Anthropic `anthropic-ratelimit-*-reset` headers for exhausted limits.

Each `run` refreshes:

```text
runs/<run-id>/report.md
runs/<run-id>/summary.html
runs/<run-id>/impact.json
runs/<run-id>/syntax.json
```

The reports summarize segment counts, style review status, findings, council decisions, revision status, verifier warnings, impact assessment, syntax shifts, and scholarly apparatus. `summary.html` is a portable static view with findings grouped by `span_id`.
The Web/API full pipeline additionally writes `report.tex` and `references.bib`.
When `--execute` produces `revised.md`, `run` also writes `revision.diff`.
Provider executions are appended to `provider.log.jsonl` without API keys or request bodies.
Each provider log entry includes `retry_count`, `retry_delay_seconds`, and `retry_statuses`, so real API runs can show when rate limits or transient errors affected the pipeline.
For real providers, add `--require-provider-ready` to fail before creating a new run when the selected provider is missing its API key:

```bash
rws run README.md --run-id cli-openai --execute --provider openai --require-provider-ready
```

To package the completed run:

```bash
rws export runs/cli-smoke-readme
```

This creates `runs/cli-smoke-readme/cli-smoke-readme-bundle.zip`.

## Segment format

`segments.json` contains stable `span_id` values:

```json
{
  "span_id": "p002",
  "type": "paragraph",
  "text": "...",
  "start_line": 3,
  "end_line": 3
}
```

These IDs are the future anchor points for style findings, council replies, synthesis changes, and verifier warnings.

## Create a review bundle

The `review` command creates a prompt bundle for one style agent. With `--execute`, it also calls the selected provider and writes completed findings.

```bash
rws review runs/cli-smoke-readme --style zalizniak-zametki
```

To execute the generated review prompt immediately:

```bash
rws review runs/cli-smoke-readme --style zalizniak-zametki --execute --provider mock
```

For several styles:

```bash
rws review runs/cli-smoke-readme --styles zalizniak-ocherk,zalizniak-zametki
```

For the current MVP council set:

```bash
rws review runs/cli-smoke-readme --mvp
```

The command creates:

```text
runs/cli-smoke-readme/reviews/
  zalizniak-zametki.prompt.md
  zalizniak-zametki.review.json
```

The prompt includes:

- the style passport;
- the full style instruction from `ClaudeStyles/`;
- `segments.json`;
- the normalized document;
- the required JSON output shape for future style findings.

The `.review.json` file starts with `status: prompt_ready` and an empty `findings` array. When `--execute` is used, it is updated to `status: completed` with a `summary` and `findings`.

## Create a council bundle

After review bundles exist:

```bash
rws council runs/cli-smoke-readme
```

To execute the council prompt:

```bash
rws council runs/cli-smoke-readme --execute --provider mock
```

The command creates:

```text
runs/cli-smoke-readme/
  council.prompt.md
  council.json
```

The council prompt includes all `reviews/*.review.json` files and `segments.json`. Without `--execute`, it creates `status: prompt_ready`; with `--execute`, it fills `replies` and `decisions`.

## Create a revision bundle

After a council artifact exists:

```bash
rws revise runs/cli-smoke-readme
```

To execute the revision prompt:

```bash
rws revise runs/cli-smoke-readme --execute --provider mock
```

The command creates:

```text
runs/cli-smoke-readme/
  revision.prompt.md
  revision.json
```

The revision prompt includes `normalized.md` and `council.json`. Without `--execute`, it creates `status: prompt_ready`; with `--execute`, it produces `revised.md` and updates the applied-change list.

When `--execute` is used, `revised.md` is written and `revision.json` is updated.

## Create a verification bundle

After a revision artifact exists:

```bash
rws verify runs/cli-smoke-readme
```

To execute the verification prompt:

```bash
rws verify runs/cli-smoke-readme --execute --provider mock
```

The command creates:

```text
runs/cli-smoke-readme/
  verification.prompt.md
  verification.json
```

The verification prompt includes the original document, normalized document, revision artifact, and revised document if one has already been produced. Without `--execute`, it creates `status: prompt_ready`; with `--execute`, it fills `passed` and `warnings`.

When `--execute` is used, `verification.json` is updated with a verifier status, passed checks, and warnings.

## Inspect findings

```bash
rws findings runs/cli-smoke-readme
rws findings runs/cli-smoke-readme --span p002
```

This prints completed style findings grouped by `span_id`, with the segment excerpt, severity, style id, finding, suggestion, and confidence.

## Inspect Provider Log

```bash
rws provider-log runs/cli-smoke-readme
```

This prints provider execution totals and per-task retry telemetry from `provider.log.jsonl`: duration, retry count, retry delay, retry statuses, and artifact path.

## Inspect Council Decisions

```bash
rws council-summary runs/cli-smoke-readme
```

This prints council status, reply count, decision count, and the accepted/deferred/informational decisions from `council.json`.

## Render a run report

```bash
rws report runs/cli-smoke-readme
rws html-report runs/cli-smoke-readme
```

`rws report` refreshes both `report.md` and `summary.html` from the JSON artifacts already present in the run directory. `rws html-report` refreshes only the static HTML summary. These commands are useful after manual edits or after executing only part of the pipeline.

## Apply Stylistic Resolutions

```bash
rws apply-resolution runs/cli-smoke-readme
```

This command reads `runs/<run-id>/resolution.json` (created via Web Studio or manually) and applies human stylistic overrides (accept/reject/defer) to the council decisions. It updates `council.json` with the resolved states.

## Finalize Manuscript

```bash
rws finalize runs/cli-smoke-readme
```

This command merges the accepted revisions and human resolutions into the final philological manuscript. It writes the results to the run directory and prepares them for final export.

## Create a revision diff

```bash
rws diff runs/cli-smoke-readme
```

This writes `runs/cli-smoke-readme/revision.diff` as a unified diff from `normalized.md` to `revised.md`.

## Export a run bundle

```bash
rws export runs/cli-smoke-readme
```

The bundle includes `report.md`, `summary.html`, `provider.log.jsonl`, source and normalized documents, JSON artifacts, prompts, `revised.md` and `revision.diff` when present, and `bundle-manifest.json`.

Use `--output` to choose a different ZIP path:

```bash
rws export runs/cli-smoke-readme --output exports/cli-smoke-readme.zip
```

## Export an eval suite bundle

```bash
rws export-eval-suite runs/cli-smoke-suite
```

The bundle includes the suite summary/report plus each referenced case run's reports, prompts, provider log, eval result, revision diff, and JSON artifacts. Use `--output` to choose a different ZIP path.

## Validate a run

```bash
rws validate-run runs/cli-smoke-readme
```

The command checks that run artifacts exist, parse as JSON where needed, pass the local JSON Schema subset for review/council/revision/verification/eval artifacts, and that any completed style findings point to known `span_id` values. Schema-sensitive fields include style `clusters`, user `profile`, council `bloom_level`, `primary_school`, and `influence` metadata.

## Validate an eval suite

```bash
rws validate-eval-suite runs/cli-smoke-suite
```

The command checks `eval-suite-result.json` against `schemas/eval-suite-result.schema.json`, verifies suite counters, confirms per-case paths exist, checks each child `eval-result.json`, and then runs the normal run validator for every referenced case run.

## Validate an eval comparison

```bash
rws validate-eval-comparison runs/eval-compare.json
```

The command checks `comparison.json` against `schemas/eval-suite-comparison.schema.json`.

## Validate a provider status

```bash
rws validate-provider-status runs/provider-status.json
```

The command checks `provider-status.json` against `schemas/provider-status.schema.json`.

## Validate the repository

```bash
python tools/validate_project.py
```

The validator currently checks:

- required docs/config/source files exist;
- JSON schemas parse;
- style manifest and passport paths resolve;
- `model_policy.yml` contains the required providers and model IDs;
- the lightweight JSON Schema validator module is present;
- `pyproject.toml` exposes the `rws` CLI.

## Run tests

```bash
python -m compileall -q src tools tests
python tools/validate_project.py
python -m unittest discover -s tests
```

The current tests cover Markdown segmentation, the full offline pipeline, mock provider execution, Markdown/HTML run reports, run export bundles, database registration, eval suite counters, and the demo input document:

```text
rws run README.md --run-id unittest-readme
```
